//
//  LivroView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 13/07/23.
//

import SwiftUI
import AVFoundation

let defaultTalePrompt = """
You are a storyteller for children. Your target audience has age between 6 and 10. You always tell fairytales. The tales you tell will always have a well defined xml structure. You always write a 3 part fairytale. After each part you will always provide a multiple choice question that defines the tale continuation. Ensure part 4 does not have an interaction section.  Ensure each part always have 4 paragraphs. Ensure the final part always has 4 paragraphs. You never speak directly at the audience.

It is absolutely vital that you include the following elements:
  
Characters: Cinderella.
Setting is: Modern city.
Items:  Diamond Sword.


Make sure to tell the story, the titles and the questions and choices in Brazilian Portuguese.
Ensure that you give the tale in a valid xml markup language. Each part always has the exact structure below:

In case is not the final part always use the structure:
<?xml version="1.0" encoding="UTF-8"?>
    For each part, but never the final, always use the structure:
    <part>
        <title>Part INSERT PART NUMBER HERE: INSERT PART TITLE HERE</title>
        <paragraphs>
            <paragraph>INSERT PARAGRAPH HERE<paragraph>
            <paragraph>INSERT OTHER PARAGRAPH HERE<paragraph>
           <paragraph>INSERT OTHER PARAGRAPH HERE<paragraph>
           <paragraph>INSERT OTHER PARAGRAPH HERE<paragraph>
        </paragraphs>
        <question>
            <interaction>INSERT QUESTION HERE</interaction>
            <choices>
                <choice> INSERT FIRST CHOICE HERE<choice>
                <choice> INSERT SECOND CHOICE HERE<choice>
                <choice> INSERT THIRD CHOICE HERE<choice>
                <choice> INSERT FOURTH CHOICE HERE<choice>
            </choices>
        <question>
    </part>
Otherwise, always use this for the final part:
    <finalpart>
        <title>INSERT FINAL PART TITLE HERE</title>
    <paragraphs>
            <paragraph>INSERT FIRST FINAL PARAGRAPH HERE</paragraph>
            <paragraph>INSERT OTHER PARAGRAPH HERE<paragraph>
            <paragraph>INSERT OTHER PARAGRAPH HERE<paragraph>
            <paragraph>INSERT FINAL PARAGRAPH HERE </paragraph>
    </paragraphs>
    </finalpart>
Don’t write anything after this.

Do not write all parts in one go. Generate each part individually, wait for the reader’s choice.
After each reader choice, there is no need to rewrite the entire story, write only the new part.
Remember that this is not a quiz, it's an interactive story. The choices should be things that the reader will choose that will impact how the story develops.
"""


struct LivroOpcoesView: View {
    
    // @Protocols
    @EnvironmentObject var router: Router
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @GestureState private var dragOffset = CGSize.zero
    @Namespace private var animation
    
    @State var isPlaying = false
    @State var isFirstPage = true // MARK: Mudar para true
    @State var isChoicesPage = false // MARK: Mudar para false
    @State var isFinalPage = false
    
    @State var advances = 0
    @State var generatedParts = [TalePart]()
    @State var currentPartIndex = 0
    @State var reachedParts = 0
    
    @State var generatedVoiceParagraphs: [String] = []
    @State var generatedVoiceQuestions: [String] = []
    @State var hasGeneratedVoice: Bool = false
    @State var voiceIndex: Int = 0
    let audioPlayerManager = AudioPlayerManager()
    
    @State var currentTextLeft = ""
    @State var currentTextRight = ""
    @State var questionText = ""
    @State var choiceAText = "A"
    @State var choiceBText = "B"
    @State var choiceCText = "C"
    @State var choiceDText = "D"
    
    @State var loading = false
    @State var openaiAPI: OpenAIAPI? = nil
    @State var apiMessages: [OpenAIChatMessage] = [
        .init(role: .system, content: defaultTalePrompt)
    ]
    
    @State var showFinalPopUp = false
    @State var currentTaleTitle = ""
    
    @Binding var shouldDismiss: Bool
    
    @State private var teste = false
    
    @Binding var contador: Contador
    
    var body: some View {
        ZStack { // Para Popup aparecer
            // Background amarelo claro
            Color.blueReg
                .opacity(0.2)
                .edgesIgnoringSafeArea(.all)
            VStack {
                // MARK: Pagina completa com opções múltipla escolha
                // Menu topo
                HStack{
                    Button(action : {
                        //                        teste.toggle()
                        //                        print(teste)
                        //                            router.reset()
                        shouldDismiss.toggle()
                        self.mode.wrappedValue.dismiss()
                        //                        resetTale() // Para testes, remover caso necessário
                    }) {
                        // Botão para Página Inicial
                        // TODO: Implementar volta para a página inicial
                        Image("Botao_xmark")
                            .resizable()
                            .frame(width: 60, height: 69)
                    }
                    
                    Spacer()
                    
                    Group{
                        HStack(spacing: 5){
                            // Botão de Rewind da Narração
                            Button {
                                audioPlayerManager.resetAudio()
                                isPlaying = false
                            } label: {
                                if hasGeneratedVoice {
                                    Image("Botao_Replay")
                                        .resizable()
                                        .frame(width: 60, height: 69)
                                        .foregroundColor(.black)
                                } else {
                                    EmptyView()
                                }
                            }.disabled(!hasGeneratedVoice)
                            // Botão de Play/Pause da Narração
                            Button {
                                if hasGeneratedVoice {
                                    if !isPlaying{
                                        isPlaying = true
                                        audioPlayerManager.playAudio(fromBase64String: generatedVoiceParagraphs[voiceIndex])
                                    }else {
                                        audioPlayerManager.pauseAudio()
                                        isPlaying = false
                                    }
                                } else {
                                    print("voice hasn't been generated")
                                }
                            } label: {
                                if hasGeneratedVoice {
                                    Image(isPlaying ? "Botao_Pause" : "Botao_Play")
                                        .resizable()
                                        .frame(width: 60, height: 69)
                                        .foregroundColor(.black)
                                } else {
                                    EmptyView()
                                }
                            }.disabled(!hasGeneratedVoice)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.top, 20)
                
                Spacer()
                // Pagina Base com botões e livro
                HStack {
                    // Fábio: Há um bug ao voltar na história, funcionalidade desabilitada por hora.
                    // Botão Esquerdo
                    // Se não primeira página, botão esquerdo aparece
                    //                    if !isFirstPage && !loading {
                    //                        Button {
                    //                            // TODO: Implementar animação pagina voltando
                    //                            //                            withAnimation {
                    //                            //                            isFirstPage = true
                    //                            //                            isChoicesPage = false
                    //                            goBack()
                    //                            //}
                    //                        } label: {
                    //                            Image("Botao_arrow.left")
                    //                                .resizable()
                    //                                .frame(width: 100, height: 114)
                    //                                .foregroundColor(.black)
                    //                        }
                    //                    }
                    
                    if loading {
                        VStack {
                            Spacer()
                            ProgressView()
                            Text("Gerando história...")
                            Spacer()
                        }
                    } else {
                        // Livro
                        if isChoicesPage {
                            VStack {
                                LivroView(larguraCaixaTexto: 320.0, alturaCaixaTexto: 500.0, larguraLivro: 930.0, alturaLivro: 680.0, textLeft: currentTextLeft, textRight: currentTextRight + questionText)
                                
                                // Opções A e C
                                HStack {
                                    Button {
                                        // TODO: Implementação do botão em si
                                        //                                    isFirstPage = false
                                        //                                    isChoicesPage = false
                                        continueTale(choice: choiceAText)
                                        audioPlayerManager.resetAudio()
                                        isPlaying = false
                                        hasGeneratedVoice = false
                                        voiceIndex += 1
                                        
                                    } label: {
                                        HStack {
                                            Image("Botao_Letra_A")
                                            ZStack {
                                                Rectangle()
                                                    .opacity(0)
                                                Text(choiceAText)
                                                    .font(.custom(.book, size: 24))
                                                    .foregroundColor(.black)
                                            }
                                            .frame(width: 402, height: 82)
                                        }
                                    }.disabled(!hasGeneratedVoice)
                                    Button {
                                        // TODO: Implementação do botão em si
                                        //                                    isFirstPage = false
                                        //                                    isChoicesPage = false
                                        continueTale(choice: choiceCText)
                                        audioPlayerManager.resetAudio()
                                        isPlaying = false
                                        hasGeneratedVoice = false
                                        voiceIndex += 1
                                    } label: {
                                        HStack {
                                            Image("Botao_Letra_C")
                                            ZStack {
                                                Rectangle()
                                                    .opacity(0)
                                                Text(choiceCText)
                                                    .font(.custom(.book, size: 24))
                                                    .foregroundColor(.black)
                                            }
                                            .frame(width: 402, height: 82)
                                        }
                                    }.disabled(!hasGeneratedVoice)
                                }
                                // Opções B e D
                                HStack {
                                    Button {
                                        // TODO: Implementação do botão em si
                                        //                                    isFirstPage = false
                                        //                                    isChoicesPage = false
                                        continueTale(choice: choiceBText)
                                        audioPlayerManager.resetAudio()
                                        isPlaying = false
                                        hasGeneratedVoice = false
                                        voiceIndex += 1
                                    } label: {
                                        HStack {
                                            Image("Botao_Letra_B")
                                            ZStack {
                                                Rectangle()
                                                    .opacity(0)
                                                Text(choiceBText)
                                                    .font(.custom(.book, size: 24))
                                                    .foregroundColor(.black)
                                            }
                                            .frame(width: 402, height: 82)
                                        }
                                    }.disabled(!hasGeneratedVoice)
                                    Button {
                                        // TODO: Implementação do botão em si
                                        //                                    isFirstPage = false
                                        //                                    isChoicesPage = false
                                        continueTale(choice: choiceDText)
                                        audioPlayerManager.resetAudio()
                                        isPlaying = false
                                        hasGeneratedVoice = false
                                        voiceIndex += 1
                                    } label: {
                                        HStack {
                                            Image("Botao_Letra_D")
                                            ZStack {
                                                Rectangle()
                                                    .opacity(0)
                                                Text(choiceDText)
                                                    .font(.custom(.book, size: 24))
                                                    .foregroundColor(.black)
                                            }
                                            .frame(width: 402, height: 82)
                                        }
                                    }.disabled(!hasGeneratedVoice)
                                }
                            }
                            //                        .matchedGeometryEffect(id: "livro", in: animation)
                        } else {
                            LivroView(larguraCaixaTexto: 360.0, alturaCaixaTexto: 590.0, larguraLivro: 1060.0, alturaLivro: 760.0, textLeft: currentTextLeft, textRight: currentTextRight)
                            //                            .matchedGeometryEffect(id: "livro", in: animation)
                        }
                        
                        // Botão Direito
                        if !isChoicesPage && !isFinalPage {
                            Button {
                                // TODO: Implementar animação pagina passando
                                //                        withAnimation {
                                //                            isFirstPage = false
                                //                            isChoicesPage = true
                                advance()
                                audioPlayerManager.resetAudio()
                                hasGeneratedVoice = false
                                isPlaying = false
                                voiceIndex += 1
                            }label: {
                                Image("Botao_arrow.right")
                                    .resizable()
                                    .frame(width: 100, height: 114)
                                    .foregroundColor(.black)
                            }.disabled(!hasGeneratedVoice)
                        }
                        
                        if isFinalPage {
                            //                            Spacer()
                            Button {
                                showFinalPopUp.toggle()
                            } label: {
                                Image("Botao_check.mark")
                                    .resizable()
                                    .frame(width: 100, height: 114)
                                    .padding(40)
                            }
                            
                        }
                    }
                }
            }
            .padding()
            .navigationBarBackButtonHidden(true)
            .gesture(
                DragGesture().updating($dragOffset, body: { (value, state, transaction) in
                    if(value.startLocation.x < 20 && value.translation.width > 100) {
                        self.mode.wrappedValue.dismiss()
                    }
                }))
            .padding()
            
            if showFinalPopUp {
                PopupFimHistoriaView(show: $showFinalPopUp, tituloHistoria: $currentTaleTitle, contador: $contador, shouldDismiss: $shouldDismiss)
            }
            
        }
        .onAppear {
            openaiAPI = OpenAIAPI()
            generatePart()
            //fakeGeneratePart()
        }
    }
}


struct TelaInicial_LivroOpcoesView_Previews: PreviewProvider {
    static var previews: some View {
        TelaInicialView()
            .environment(\.locale, .init(identifier: "en"))
            .environmentObject(Router())
    }
}

struct LivroOpcoesView_Previews: PreviewProvider {
    static var previews: some View {
        @State var shouldDismiss = false
        @State var contador = Contador(chaves: 3, moedas: 2)
        LivroOpcoesView(shouldDismiss: $shouldDismiss, contador: $contador)
            .environment(\.locale, .init(identifier: "pt-BR"))
            .environmentObject(Router())
    }
}


extension LivroOpcoesView {
    private func advance() {
        if advances >= (TalePart.totalDePartes * 2) {
            return
        }
        advances += 1
        if advances > 0 {
            isFirstPage = false
        }
        if advances % 2 == 1 {
            isChoicesPage = true
        }
        loadPart()
    }
    
    private func goBack() { // Fabio - TODO: Navegação de história quebra ao voltar a primeira parte
        //        if isFirstPage {
        //            return
        //        }
        //        if isChoicesPage {
        //            isChoicesPage = false
        //            isFirstPage = false
        //            isFinalPage = false
        //        }
        //        advances -= 1
        //        loadPart()
    }
    
    private func loadPart() {
        updateCurrentPartIndex()
        let currentPart = generatedParts.last!
        if (advances % 2 == 0) && (advances < 6) {
            currentTextLeft = "\(currentPartIndex + 1) | \(currentPart.paragraphs[0])"
            currentTextRight = currentPart.paragraphs[1]
        } else if (advances % 2 != 0) && (advances < 6) {
            currentTextLeft = currentPart.paragraphs[2]
            currentTextRight = currentPart.paragraphs[3]

        } else {
            currentTextLeft = "\(currentPart.paragraphs[0]) \(currentPart.paragraphs[1])"
            currentTextRight = "\(currentPart.paragraphs[2]) \(currentPart.paragraphs[3])"
        }
        if currentPartIndex <= 2 {
            if let choices = currentPart.choices {
                choiceAText = choices[0]
                choiceBText = choices[1]
                choiceCText = choices[2]
                choiceDText = choices[3]
            } else {
                print("Houve um problema com as escolhas")
            }
        }
        if advances == 0 {
            isFirstPage = true
        }
        if (advances % 2 == 1) && advances >= (reachedParts * 2){
            isChoicesPage = true
        }
        isFinalPage = advances == (TalePart.totalDePartes * 2)
//        print("\(currentPartIndex) | \(advances)")
        generateVoiceParagraph(genText: currentTextLeft+currentTextRight, lingua: .ptBR)
    }
    
    // MARK: voice functions
    func generateVoiceParagraph(genText: String, lingua:  VoiceType){
        
        guard !genText.isEmpty else { return }
        //isPlaying = true
        SpeechService.voice.speak(text: genText, voiceType: lingua)
        {audioString in
            generatedVoiceParagraphs.append(audioString)
            hasGeneratedVoice = true
            
        }
        
    }
    
    func generateVoiceQuestion(genText: String, lingua:  VoiceType){
        
        guard !genText.isEmpty else { return }
        //isPlaying = true
        SpeechService.voice.speak(text: genText, voiceType: lingua)
        {audioString in
            generatedVoiceQuestions.append(audioString)
            hasGeneratedVoice = true
        }
        
    }
    
    private func generatePart(choice: String? = nil) {
        var next: TalePart
        if currentPartIndex == 2 {
            Task {
                do {
                    await MainActor.run {
                        if let choice {
                            let continuationMessage: OpenAIChatMessage = .init(role: .user, content: "Finish with choice: \(choice).")
                            apiMessages.append(continuationMessage)
                        }
                        loading = true
                    }
                    let response = try await openaiAPI!.enviarPrompt(mensagensEnviadas: apiMessages)
                    print("Generated final part")
                    print(response)
                    let finalPart = try TalePart.convertIntoPart(textContent: response.content, finalPart: true)
                    await MainActor.run {
                        loading = false
                        generatedParts.append(finalPart)
                        loadPart()
                    }
                } catch {
                    print("paia 2")
                    print(error)
                }
            }
            do {
                let part = try TalePart.convertIntoPart(textContent: fakeFinalPart)
                next = part
                generatedParts.append(next)
                loadPart()
            } catch {
                print("parte final com problemas")
                print(error)
            }
        } else {
            Task {
                //                    print("entered task")
                do {
                    await MainActor.run {
                        if let choice {
                            let continuationMessage: OpenAIChatMessage = .init(role: .user, content: "Continue with choice: \(choice)")
                            apiMessages.append(continuationMessage)
                        }
                        print("Entered load")
                        loading = true
                    }
                    //                        print("sending prompt")
                    let response = try await openaiAPI!.enviarPrompt(mensagensEnviadas: apiMessages)
                    apiMessages.append(response)
                    //                        print("converting prompt")
                    let nextPart = try TalePart.convertIntoPart(textContent: response.content)
                    await MainActor.run {
                        let _ = response
                        //                            print("atualizando tela")
                        let copy = nextPart
                        questionText = copy.question ?? ""
                        generatedParts.append(nextPart)
                        loading = false
                        loadPart()
                    }
                } catch {
                    print("parte gerada com problema")
                    print(error)
                }
            }
            
        }
        
    }
    
    private func fakeGeneratePart(choice: String? = nil) {
        if currentPartIndex == 2 {
            do {
                let part = try TalePart.convertIntoPart(textContent: fakeFinalPart,finalPart: true)
                let next: TalePart = part
                generatedParts.append(next)
                loadPart()
            } catch {
                print("parte final com problemas")
                print(error)
            }
        } else {
            do {
                let part = try TalePart.convertIntoPart(textContent: fakePart)
                let next: TalePart = part
                generatedParts.append(next)
                loadPart()
            } catch {
                print("parte com problemas")
                print(error)
            }
        }
    }
    
    private func continueTale(choice: String) {
        Task {
            await MainActor.run {
                isChoicesPage = false
                reachedParts += 1
                generatePart(choice: choice)
                // fakeGeneratePart()
                advance()
                updateCurrentPartIndex()
            }
        }
    }
    
    private func updateCurrentPartIndex() {
        if advances <= 1 {
            currentPartIndex = 0
        } else if advances <= 3 {
            currentPartIndex = 1
        } else if advances <= 5 {
            currentPartIndex = 2
        } else {
            currentPartIndex = 3 // parte final
        }
    }
}
