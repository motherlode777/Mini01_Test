//
//  LivroView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 13/07/23.
//

import SwiftUI

struct LivroView: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @GestureState private var dragOffset = CGSize.zero
    
    var larguraCaixaTexto: CGFloat
    var alturaCaixaTexto: CGFloat
    var larguraLivro: CGFloat
    var alturaLivro: CGFloat
    let textLeft: String
    let textRight: String
    
    var body: some View {
        NavigationStack {
            // Livro
            ZStack {
                Image("Livro")
                    .resizable()
                    .padding()
                
                HStack{
                    Spacer()
                    Text(textLeft)
                        .frame(width: larguraCaixaTexto, height: alturaCaixaTexto)
                        .font(.custom(.book, size: 24))
                        .foregroundColor(.black)
                    Spacer()
                    Text(textRight)
                        .frame(width: larguraCaixaTexto, height: alturaCaixaTexto)
                        .font(.custom(.book, size: 24))
                        .foregroundColor(.black)
                    Spacer()
                }
//                .opacity(0.5)
                .frame(width: larguraLivro)
                .padding(.bottom, 150) // TODO: Ajustar quando trocar o livro
            }
            .frame(width: larguraLivro, height: alturaLivro)
        }
    }
}

struct TelaInicial_LivroView_Previews: PreviewProvider {
    static var previews: some View {
        TelaInicialView()
            .environment(\.locale, .init(identifier: "en"))
    }
}

struct LivroView_Previews: PreviewProvider {
    static var previews: some View {
        let larguraCaixaTexto: CGFloat = 360.0
        let alturaCaixaTexto: CGFloat = 590.0
        let larguraLivro: CGFloat = 1060.0
        let alturaLivro: CGFloat = 760.0
        LivroView(larguraCaixaTexto: larguraCaixaTexto, alturaCaixaTexto: alturaCaixaTexto, larguraLivro: larguraLivro, alturaLivro: alturaLivro, textLeft: "teste-string", textRight: "teste-string")
            .environment(\.locale, .init(identifier: "pt-BR"))
    }
}
