//
//  PopupsView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 18/07/23.
//

import SwiftUI

struct PopupTesouroView: View {
    @Binding var show: Bool
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                Image("Tesouro")
                
                Text("You've successfully completed the work")
                
                Button {
                    
                } label: {
                    Text("Back to home")
                        .foregroundColor(.white)
                        .bold()
                        .padding(.vertical, 10)
                        .padding(.horizontal, 25)
                        .background(Color.purple)
                        .clipShape(Capsule())
                }
            }
            .padding(.vertical, 25)
            .padding(.horizontal, 30)
            .background(BlurView())
            .cornerRadius(25)
            
            Button {
                withAnimation{
                    show.toggle()
                }
            } label: {
                Image(systemName: "xmark.circle")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.purple)
            }
            .padding()

        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}


struct PopupFimHistoriaView: View {
    @Binding var show: Bool
    @Binding var tituloHistoria: String
    @Binding var contador: Contador
    @Binding var shouldDismiss: Bool
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    @State var estrelas = [true, true, true, true, true]
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                Text("fim-string")
                    .font(.custom(.medium, size: 40))
                    .foregroundColor(.escrita)
                
                // TODO: Implementar teclado
                TextField("titulo_historia-string", text: $tituloHistoria)
                    .textFieldStyle(RoundedTextFieldStyle())
                    .frame(width: 430)
                    .padding(.bottom, 30)
                
                Button {
                    // TODO: Implementar navegação para pagina de desenho
                } label: {
                    ZStack{
                        Image("Botao_Popup")
                        Text("desenhar_capa-string")
                            .foregroundColor(.escrita)
                            .font(.custom(.medium, size: 24))
                            .padding(.vertical, 10)
                            .padding(.horizontal, 25)
                    }
                }
                
                Button {
                    // TODO: Implementação salvar historia
                    show.toggle()
                    contador.chaves += 1
                    print(contador)
                    shouldDismiss.toggle()
                    self.mode.wrappedValue.dismiss()
                } label: {
                    ZStack{
                        Image("Botao_Popup")
                        Text("salvar_historia-string")
                            .foregroundColor(.escrita)
                            .font(.custom(.medium, size: 24))
                            .padding(.vertical, 10)
                            .padding(.horizontal, 25)
                    }
                }
                
                Text("avaliacao_historia-string")
                    .font(.custom(.medium, size: 24))
                    .foregroundColor(.escrita)
                
                HStack{
                    Button {
                        estrelas = [true, false, false, false, false]
                    } label: {
                        Image(systemName: estrelas[0] ? "star.fill" : "star")
                            .font(.system(size: 40))
                    }
                    Button {
                        estrelas = [true, true, false, false, false]
                    } label: {
                        Image(systemName: estrelas[1] ? "star.fill" : "star")
                            .font(.system(size: 40))
                    }
                    Button {
                        estrelas = [true, true, true, false, false]
                    } label: {
                        Image(systemName: estrelas[2] ? "star.fill" : "star")
                            .font(.system(size: 40))
                    }
                    Button {
                        estrelas = [true, true, true, true, false]
                    } label: {
                        Image(systemName: estrelas[3] ? "star.fill" : "star")
                            .font(.system(size: 40))
                    }
                    Button {
                        estrelas = [true, true, true, true, true]
                    } label: {
                        Image(systemName: estrelas[4] ? "star.fill" : "star")
                            .font(.system(size: 40))
                    }
                }
                .foregroundColor(.yellow)
                
                Text("nova_chave-string")
                    .font(.custom(.bold, size: 14))
                    .foregroundColor(.escrita)
            }
            .padding(.vertical, 25)
            .padding(.horizontal, 30)
            .background(BlurView())
            .cornerRadius(25)
            //
            //            Button {
            //                withAnimation{
            //                    show.toggle()
            //                }
            //            } label: {
            //                Image(systemName: "xmark.circle")
            //                    .font(.system(size: 28, weight: .bold))
            //                    .foregroundColor(Color.gray)
            //            }
            //            .padding()
            //
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}

struct PopupUtilizarMoedasView: View {
    @Binding var show: Bool
    @Binding var contador: Contador
    @State var falsidade = false
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                Text("utilizar_moedas-string")
                    .multilineTextAlignment(.center)
                    .frame(width: 350, height: 150)
                    .font(.custom(.medium, size: 40))
                    .foregroundColor(.escrita)

                Text("suas_moedas-string")
                    .font(.custom(.bold, size: 24))
                    .foregroundColor(.yellow)

                VStack(spacing: 5){
                    Image("Moeda")
                        .resizable()
                        .frame(width: 77, height: 73)
                    
                    Text("\(contador.moedas)")
                        .font(.custom(.medium, size: 48))
                        .foregroundColor(.escrita)
                    
                }
                
                HStack {
                    Button {
                        if contador.moedas > 0 {
                            contador.moedas -= 1
                        }
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("sim-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
//                    NavigationLink(destination: DesenhoView()) {
//                        ZStack{
//                            Image("Botao_Popup")
//                                .resizable()
//                                .frame(width: 211, height: 62)
//                            Text("sim-string")
//                                .foregroundColor(.escrita)
//                                .font(.custom(.medium, size: 24))
//                                .padding(.vertical, 10)
//                                .padding(.horizontal, 25)
//                        }
//                    }
//                    .onTapGesture {
//                    if contador.moedas > 0 {
//                        contador.moedas -= 1
//                    }
//                    }
                    
                    Button {
                        // TODO: Implementação salvar historia
                        show.toggle()
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("nao-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                }
            }
            .padding(.vertical, 25)
            .padding(.horizontal, 30)
            .background(BlurView())
            .cornerRadius(25)
            //
            //            Button {
            //                withAnimation{
            //                    show.toggle()
            //                }
            //            } label: {
            //                Image(systemName: "xmark.circle")
            //                    .font(.system(size: 28, weight: .bold))
            //                    .foregroundColor(Color.gray)
            //            }
            //            .padding()
            //
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}

struct PopupSemMoedasView: View {
    @Binding var show: Bool
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                Text("sem_moedas-string")
                    .multilineTextAlignment(.center)
                    .frame(width: 429)
                    .font(.custom(.medium, size: 40))
                    .foregroundColor(.escrita)
                
                Text("adquirir_moedas-string")
                    .multilineTextAlignment(.center)
                    .frame(width: 429)
                    .font(.custom(.medium, size: 40))
                    .foregroundColor(.escrita)
                
                Button {
                    // TODO: Implementação salvar historia
                    show.toggle()
                } label: {
                    ZStack{
                        Image("Botao_Icone_Compra")
                            .resizable()
                            .frame(width: 100, height: 114)
                    }
                }
            }
            .padding(.vertical, 80)
            .padding(.horizontal, 80)
            .background(BlurView())
            .cornerRadius(25)
            
            Button {
                withAnimation{
                    show.toggle()
                }
            } label: {
                Image("Botao_xmark_Popup")
                    .frame(width: 60, height: 69)
            }
            .padding()
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}

struct PopupPerdaMoedaView: View {
    @Binding var show: Bool
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                
                    Text("retornar-string")
                        .multilineTextAlignment(.center)
                        .frame(width: 421, height: 100)
                        .font(.custom(.medium, size: 40))
                        .foregroundColor(.escrita)

                    Text("perda_moeda-string")
                        .multilineTextAlignment(.center)
                        .frame(width: 421, height: 150)
                        .font(.custom(.medium, size: 40))
                        .foregroundColor(.escrita)

                VStack(spacing: 15){
                    Button {
                        // TODO: Implementar navegação para pagina inicial
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("continuar-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                    
                    Button {
                        show.toggle()
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("sair-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                }
            }
            .padding(.vertical, 25)
            .padding(.horizontal, 30)
            .background(BlurView())
            .cornerRadius(25)
            //
            //            Button {
            //                withAnimation{
            //                    show.toggle()
            //                }
            //            } label: {
            //                Image(systemName: "xmark.circle")
            //                    .font(.system(size: 28, weight: .bold))
            //                    .foregroundColor(Color.gray)
            //            }
            //            .padding()
            //
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}

struct PopupSelecaoIconeView: View {
    @Binding var show: Bool
    
    @State var elemento: ObjetoHistoria = ObjetoHistoria(id: UUID(), nome: "vassoura_voadora-string", imagem: "Vassoura Voadora", tipo: "Personagem")
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                
                    VStack(spacing: 10){
                        Text(NSLocalizedString(elemento.nome, comment: ""))
                            .font(.custom(.medium, size: 40))
                            .foregroundColor(.escrita)

                        Image(elemento.nome)
                        .resizable()
                        .frame(width: 224, height: 224)
                        
                        Text(NSLocalizedString(elemento.tipo, comment: ""))
                            .font(.custom(.bold, size: 24))
                            .foregroundColor(.yellow)
                    }

                VStack(spacing: 15){
                    Button {
                        // TODO: Implementar navegação para pagina inicial
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("selecionar-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                    
                    Button {
                        show.toggle()
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("cancelar-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                }
            }
            .frame(width: 530, height: 566)
            .background(BlurView())
            .cornerRadius(25)
            //
            //            Button {
            //                withAnimation{
            //                    show.toggle()
            //                }
            //            } label: {
            //                Image(systemName: "xmark.circle")
            //                    .font(.system(size: 28, weight: .bold))
            //                    .foregroundColor(Color.gray)
            //            }
            //            .padding()
            //
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}

struct PopupIconeBloqueadoView: View {
    @Binding var show: Bool
    
    @State var elemento: ObjetoHistoria = ObjetoHistoria(id: UUID(), nome: "Branca de Neve", imagem: "Vassoura Voadora", tipo: "Personagem")
    
    var body: some View {
        ZStack(alignment: Alignment(horizontal: .trailing, vertical: .top)) {
            VStack(spacing: 25){
                
                    VStack(spacing: 10){
                        Text(NSLocalizedString(elemento.nome, comment: ""))
                            .font(.custom(.medium, size: 40))
                            .foregroundColor(.escrita)

                        Image(elemento.nome)
                        .resizable()
                        .frame(width: 224, height: 224)
                        
                        Text(NSLocalizedString(elemento.tipo, comment: ""))
                            .font(.custom(.bold, size: 24))
                            .foregroundColor(.yellow)
                    }

                VStack(spacing: 15){
                    Button {
                        // TODO: Implementar navegação para pagina inicial
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("selecionar-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                    
                    Button {
                        show.toggle()
                    } label: {
                        ZStack{
                            Image("Botao_Popup")
                                .resizable()
                                .frame(width: 211, height: 62)
                            Text("cancelar-string")
                                .foregroundColor(.escrita)
                                .font(.custom(.medium, size: 24))
                                .padding(.vertical, 10)
                                .padding(.horizontal, 25)
                        }
                    }
                }
            }
            .frame(width: 530, height: 566)
            .background(BlurView())
            .cornerRadius(25)
            //
            //            Button {
            //                withAnimation{
            //                    show.toggle()
            //                }
            //            } label: {
            //                Image(systemName: "xmark.circle")
            //                    .font(.system(size: 28, weight: .bold))
            //                    .foregroundColor(Color.gray)
            //            }
            //            .padding()
            //
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(
            Color.primary.opacity(0.35)
        )
    }
}


struct PopupView_Previews_ptBR: PreviewProvider {
    static var previews: some View {
        @State var show = true
        @State var tituloHistoria = ""
        @State var contador = Contador(chaves: 0, moedas: 2)
        
        PopupIconeBloqueadoView(show: $show, elemento: ObjetoHistoria(id: UUID(), nome: "Branca de Neve", imagem: "Branca de Neve", tipo: "Personagem"))
            .environment(\.locale, .init(identifier: "en"))
    }
}
