//
//  MinhasHistoriasView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 14/07/23.
//

import SwiftUI
import MobileCoreServices

struct MinhasHistoriasView: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @GestureState private var dragOffset = CGSize.zero
    
    @State private var favoritos = false
    
    @ObservedObject var delegate = MockImages()
    

    @FetchRequest(sortDescriptors: []) var desenhos: FetchedResults<Historia>
    let corRandomica: [Color] = [.tealDrk, .redReg, .orangeReg, .yellowReg, .greenLgt, .tealReg]
    
    let columns = [
        GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            
            // Background amarelo claro
            Color.blueReg
                .opacity(0.2)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                HStack {
                    Button(action : {
                        self.mode.wrappedValue.dismiss()
                    }) {
                        // Botão para Página Inicial
                        // TODO: Implementar volta para a página inicial
                        Image("Botao_xmark")
                            .resizable()
                            .frame(width: 60, height: 69)
                            .foregroundColor(.black)
                    }
                    Spacer()
                    
                    Button {
                        withAnimation(.easeIn) {
                            favoritos.toggle()
                        }
                    } label: {
                        if favoritos {
                            Image("Toggle_On")
                        } else {
                            Image("Toggle_Off")
                        }
                    }
                    
                }
                .padding(.horizontal, 40)
                .padding(.vertical, 10)
                
                ScrollView {
                    
                    LazyVGrid(columns: columns, spacing: 50) {
                        ForEach(desenhos) { desenho in
                            
                            HStack {
                                VStack(spacing: 0) {
                                    if let data = desenho.desenhocapa, let uiimage = UIImage(data: data) {
                                        Image(uiImage: uiimage)
                                            .resizable()
                                            .frame(width: 283, height: 238)
                                            .background(.white)
                                            .background(Color.white)
                                            .mask(
                                                Rectangle().cornerRadius(radius: 30.0, corners: [.topLeft, .topRight])
                                            )
                                            
                                    }
                                    ZStack {
                                        Rectangle()
                                            .cornerRadius(radius: 30, corners: [.bottomLeft,.bottomRight])
                                            .frame(width: 283, height: 96)
                                            .foregroundColor(corRandomica.randomElement())
                                        Text("titulo_historia-string")
                                            .frame(width: 283, height: 96)
                                            .font(.custom(.medium, size: 32))
                                            .foregroundColor(.white)
                                    }
                                    
                                }
                                
                                VStack{
                                    Button{
                                        favoritos.toggle()
                                    } label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 15)
                                                .frame(width: 70, height: 50)
                                                .foregroundColor(.white)
                                            Image(systemName: favoritos ? "star.fill" : "star")
                                                .foregroundColor(.black)
                                                .font(.system(size: 25))
                                        }
                                    }
                                    
                                    Button{
                                        // TODO: Implementar parte de salvar texto com as escolhas da criança
                                    } label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 15)
                                                .frame(width: 70, height: 50)
                                                .foregroundColor(.white)
                                            Image(systemName: "square.and.arrow.down")
                                                .foregroundColor(.black)
                                                .font(.system(size: 25))
                                        }
                                    }
                                    
                                    Button{
                                        // TODO: Implementar parte de deletar história
                                    } label: {
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 15)
                                                .frame(width: 70, height: 50)
                                                .foregroundColor(.white)
                                            Image(systemName: "trash")
                                                .foregroundColor(.black)
                                                .font(.system(size: 25))
                                        }
                                    }
                                    
                                    Spacer()
                                }
                            }
                            
                        }
                    }
                    .padding(.horizontal, 80)
                }
                .navigationBarBackButtonHidden(true)
                .gesture(DragGesture().updating($dragOffset, body: { (value, state, transaction) in
                    if(value.startLocation.x < 20 && value.translation.width > 100) {
                        self.mode.wrappedValue.dismiss()
                    }
                }))
                .padding()
            }
        }
    }
}

struct MinhasHistoriasView_Previews: PreviewProvider {
    static var previews: some View {
        MinhasHistoriasView()
    }
}

