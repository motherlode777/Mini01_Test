//
//  TelaInicialView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 11/07/23.
//

import SwiftUI

struct TelaInicialView: View {
    
    // @Protocols
    @EnvironmentObject var router: Router
    
    
    // Toggles para Popups
    @State var showPopup = false
    @State var show = false
    @State var showPopupSemMoedas = false
    
    
    @State var isMusicOn = true
    @State var tituloHistoria = ""
    
    @State var contador: Contador = Contador(chaves: 3, moedas: 2)
    
    
    var body: some View {
        ZStack { // Para Popup aparecer
            
            NavigationStack(path: $router.path) {
                ZStack { // Para fundo colorido
                    
                    // Background verde claro
                    Color.greenReg
                        .opacity(0.5)
                        .edgesIgnoringSafeArea(.all)
                    
                    VStack{
                        HStack {
                            Spacer()
                            
                            // Botão para página de Configurações
                            Button{
                                isMusicOn.toggle()
                                // TODO: Implementar navegação para página de configurações
                            } label: {
                                Image(isMusicOn ?  "Botao_Musica_On" : "Botao_Musica_Off")
                                    .resizable()
                                    .frame(width: 60, height: 68.3)
                                    .foregroundColor(.black)
                            }
                            .padding(.vertical, 40)
                        }
                        .padding(.horizontal, 40)
                        
                        Spacer()
                        
                        // MARK: Botões História
                        // Botão para página de "Minhas Histórias"
                        NavigationLink(destination: { SelecaoElementosView(contador: $contador)
                        }, label: {
                            ZStack {
                                Image("Botao_Nova_Historia")
                                    .frame(width: 430, height: 155)
                                Text("nova_historia-string")
                                    .foregroundColor(.escrita)
                                    .font(.custom(.medium, size: 40))
                                    .frame(width: 370, height: 100)
                            }
                        })
                        .padding()
                        
                        // Botão para página de "Minhas Histórias"
                        NavigationLink(destination: {
                            MinhasHistoriasView()
                        }, label: {
                            ZStack {
                                Image("Botao_Minhas_Historias")
                                    .frame(width: 360, height: 130)
                                Text("minhas_historias-string")
                                    .foregroundColor(.escrita)
                                    .font(.custom(.medium, size: 40))
                                    .frame(width: 317, height: 91)
                            }
                        })
                        .padding()
                        
                        Spacer()
                        
                        HStack {
                            // Botão para página de recompensa
                            Button{
                                // TODO: Implementar navegação página de recompensa
                                show.toggle()
                            } label: {
                                Image("Tesouro")
                                    .resizable()
                                    .frame(width: 164, height: 172)
                                VStack(spacing: 5){
                                    ZStack {
                                        Image("Capsula_e_Chave")
                                            .resizable()
                                            .frame(width: 127, height: 46)
                                        Text("\(contador.chaves)")
                                            .padding(.leading)
                                            .foregroundColor(.escrita)
                                            .font(.custom(.bold, size: 32))
                                    }
                                    ZStack {
                                        Image("Capsula_e_Moeda")
                                            .resizable()
                                            .frame(width: 127, height: 46)
                                        Text("\(contador.moedas)")
                                            .padding(.leading)
                                            .foregroundColor(.escrita)
                                            .font(.custom(.bold, size: 32))
                                    }
                                    
                                }
                                .padding(.top, 65)
                                Button {
                                    // TODO: Implementação do botão de compra
                                    showPopupSemMoedas.toggle()
                                } label: {
                                    Image("Icone_Compra")
                                }
                                .padding(.top, 65)
                                .frame(width: 44, height: 91)
                                
                            }
                            .frame(width: 150, height: 180)
                            
                            Spacer()
                        }
                        .padding(.horizontal, 100)
                        
                    }
                    .padding()
                }
            }
            
            // ShowPopups
            if show {
                if contador.moedas > 0 {
                    PopupUtilizarMoedasView(show: $show, contador: $contador)
                } else {
                    PopupSemMoedasView(show: $show)
                }
            }
            
            if showPopupSemMoedas {
                PopupSemMoedasView(show: $showPopupSemMoedas)
            }
            
        }
//        .popupNavigationView(show: $showPopup) {
//            Text("Nossa Popup funciona!!")
//                .toolbar {
//                    ToolbarItem(placement: .navigationBarLeading) {
//                        Button("Close"){
//                            withAnimation {
//                                showPopup.toggle()
//                            }
//                        }
//                    }
//                }
//        }

    }
}

struct TelaInicialView_Previews_ptBR: PreviewProvider {
    static var previews: some View {
        TelaInicialView()
            .environment(\.locale, .init(identifier: "pt-BR"))
            .environmentObject(Router())
    }
}

struct TelaInicialView_Previews_en: PreviewProvider {
    static var previews: some View {
        TelaInicialView()
            .environment(\.locale, .init(identifier: "en"))
            .environmentObject(Router())
    }
}

