//
//  SelecaoElementosView.swift
//  Mini01
//
//  Created by Letícia Malagutti on 11/07/23.
//

import SwiftUI
import MobileCoreServices
import Algorithms

struct SelecaoElementosView: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    @GestureState private var dragOffset = CGSize.zero
    
    @Environment(\.dismiss) var dismiss
    
    @State private var elementosTotal: [ObjetoHistoria] = [
        DadosElementos.elemento1, DadosElementos.elemento2,
        DadosElementos.elemento3, DadosElementos.elemento4,
        DadosElementos.elemento5, DadosElementos.elemento6,
        DadosElementos.elemento7, DadosElementos.elemento8,
        DadosElementos.elemento9, DadosElementos.elemento10,
        DadosElementos.elemento11
    ]
    @State private var livroElementos: [ObjetoHistoria] = []
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let rows = [
        GridItem(.flexible()), GridItem(.flexible())
    ]
    
    //    @ObservedObject var delegate = DadosElementos()
    // Informações vindas de outras telas
    @State var shouldDismiss = false
    
    @State var show = false
    @State var elementoPopup = ObjetoHistoria(id: UUID(), nome: "", imagem: "", tipo: "")
    
    @Binding var contador: Contador
    
    
    var body: some View {
        ZStack { // Para Popup aparecer
            // Background amarelo claro
            Color.blueReg
                .opacity(0.2)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0){
                // MARK: Elementros e Livro
                // Menu toppo
                HStack{
                    Button(action : {
                        self.mode.wrappedValue.dismiss()
                    }) {
                        // Botão para Página Inicial
                        // TODO: Implementar volta para a página inicial
                        Image("Botao_xmark")
                            .resizable()
                            .frame(width: 60, height: 69)
                    }
                    
                    Spacer()
                    
                    Group{
                        VStack(spacing: 5){
                            ZStack {
                                Image("Capsula_e_Chave")
                                    .resizable()
                                    .frame(width: 127, height: 46)
                                Text("\(contador.chaves)")
                                    .padding(.leading)
                                    .foregroundColor(.escrita)
                                    .font(.custom(.bold, size: 32))
                            }
                            ZStack {
                                Image("Capsula_e_Moeda")
                                    .resizable()
                                    .frame(width: 127, height: 46)
                                Text("\(contador.moedas)")
                                    .padding(.leading)
                                    .foregroundColor(.escrita)
                                    .font(.custom(.bold, size: 32))
                            }
                            
                        }
                        .padding([.horizontal, .top], 40)
                    }
                }
                .padding(.horizontal, 40)
                
                VStack(spacing: 0){
                    HStack{
                        // Elementos
                        VStack{
                            Text("escolha_elementos-string")
                                .font(.custom(.medium, size: 40))
                                .multilineTextAlignment(.center)
                                .foregroundColor(.escrita)
                                .frame(width: 510, height: 120)
                            
                            ScrollView{
                                // Matriz com elementos a serem adicionados
                                LazyVGrid(columns: columns) {
                                    ForEach(elementosTotal) { elemento in
                                        
                                        Button {
                                            show.toggle()
                                            elementoPopup = elemento
                                        } label: {
                                            Image(elemento.nome)
                                                .resizable()
                                                .frame(width: 185, height: 185)
                                                .draggable(elemento)
                                        }
                                        
                                        //                                                .clipShape(Circle())
                                        //                                                .onDrag {
                                        //                                                    NSItemProvider(item: .some(URL(string: image.image)! as NSSecureCoding), typeIdentifier: String(kUTTypeURL))
                                        //                                                }
                                        //                                Circle()
                                        //                                    .frame(width: 185, height: 185)
                                        //                                    .foregroundColor(Color(UIColor.systemGray4))
                                    }
                                }
                                .padding()
                            }
                        }
                        
                        //                        Spacer()
                        
                        // Livro
                        VStack{
                            //
                            //                            if livroElementos.count > 0 {
                            //                                Spacer()
                            //                            }
                            
                            // Drop Area
                            ZStack {
                                Image("Livro")
                                    .resizable()
                                    .scaledToFit()
                                    .padding(.trailing,50)
                                
                                LazyHGrid(rows: rows, spacing: 5){
                                    ForEach(livroElementos, id: \.id){ elemento in
                                        ZStack {
                                            Button {
                                                show.toggle()
                                                elementoPopup = elemento
                                            } label: {
                                                Image(elemento.nome)
                                                    .resizable()
                                                    .frame(width: 100, height: 100)
                                            }
                                            
                                            // Botão de remover
                                            Button {
                                                withAnimation(.easeOut){
                                                    self.livroElementos.removeAll { (check) -> Bool in
                                                        if check.nome == elemento.nome {
                                                            return true
                                                        } else {
                                                            return false
                                                        }
                                                    }
                                                }
                                            } label: {
                                                Image(systemName: "xmark")
                                                    .foregroundColor(.white)
                                                    .padding(10)
                                                    .background(.black)
                                                    .clipShape(Circle())
                                            }
                                        }
                                        
                                    }
                                }
                                .frame(width: 500, height: 300)
                            }
                            //                                // Recebe a infromação da imagem
                            .dropDestination(for: ObjetoHistoria.self) { droppedElements, location in
                                
                                let totalElements = livroElementos + droppedElements
                                livroElementos = Array(totalElements.uniqued())
                                
                                return true
                            }
                            //                                .onDrop(of: [String(kUTTypeURL)], delegate: delegate)
                            
                            
                            HStack {
                                Spacer()
                                // Lógica para o botão só aparecer se tiver pelo menos um personagem selecionado
                                if (livroElementos.filter{$0.tipo == "Personagem"}.count > 0 ){
                                    // Botão para próxima tela
                                    NavigationLink {
                                        LivroOpcoesView(shouldDismiss: $shouldDismiss, contador: $contador)
                                    } label: {
                                        Image("Botao_check.mark")
                                            .resizable()
                                            .frame(width: 100, height: 114)
                                            .padding(40)
                                    }
                                } else {EmptyView()}
                            }
                            .padding()
                            
                        }
                        .frame(width: 700)
                        .padding(.trailing)
                    }
                    .padding()
                }
            }
            .navigationBarBackButtonHidden(true)
            .gesture(DragGesture().updating($dragOffset, body: { (value, state, transaction) in
                if(value.startLocation.x < 20 && value.translation.width > 100) {
                    self.mode.wrappedValue.dismiss()
                }
            }))
            .padding()
            
            if show {
                PopupSelecaoIconeView(show: $show, elemento: elementoPopup)
            }
        }
        .edgesIgnoringSafeArea(.all)
        .task {
            if shouldDismiss {
                dismiss()
            }
        }
    }
}

struct SelecaoElementosView_Previews: PreviewProvider {
    static var previews: some View {
        @State var contador = Contador(chaves: 3, moedas: 2)
        
        SelecaoElementosView(contador: $contador)
            .environment(\.locale, .init(identifier: "pt-BR"))
            .environmentObject(Router())
    }
}


struct TelaInicial_SelecaoElementosView_Previews: PreviewProvider {
    static var previews: some View {
        TelaInicialView()
            .environment(\.locale, .init(identifier: "pt-BR"))
            .environmentObject(Router())
    }
}
