//
//  Structs.swift
//  Mini01
//
//  Created by Letícia Malagutti on 17/07/23.
//

import SwiftUI
import UniformTypeIdentifiers
import MobileCoreServices

struct StrokeText: View {
    let text: String
    let width: CGFloat
    let color: Color

    var body: some View {
        ZStack{
            ZStack{
                Text(text).offset(x:  width, y:  width)
                Text(text).offset(x: -width, y: -width)
                Text(text).offset(x: -width, y:  width)
                Text(text).offset(x:  width, y: -width)
            }
            .foregroundColor(color)
            Text(text)
        }
    }
}

class MockImages : ObservableObject, DropDelegate {
    @Published var totalImagens: [Imagem] = [
        Imagem(id: 0, image: "p1"), Imagem(id: 1, image: "p2"),
        Imagem(id: 2, image: "p3"), Imagem(id: 3, image: "p4"),
        Imagem(id: 4, image: "p5"), Imagem(id: 5, image: "p6"),
        Imagem(id: 6, image: "p7"), Imagem(id: 7, image: "p8"),
        Imagem(id: 8, image: "p9"), Imagem(id: 9, image: "p10")
    ]
    
    @Published var elementosSelecionados: [Imagem] = []
    
    func performDrop(info: DropInfo) -> Bool {
        // Adiciona imagens à view do livro
        
        for provider in info.itemProviders(for: [String(kUTTypeURL)]) {
            
            // Confere se está disponível
            
            if provider.canLoadObject(ofClass: URL.self) {
                print("URL Loaded")
                
                let _ = provider.loadObject(ofClass: URL.self) { (url, err) in
                    print(url!)
                    
                    // Percorre o array e vê se já foi adicionado
                    
                    let status = self.elementosSelecionados.contains{ (check) -> Bool in
                        if check.image == "\(url!)" {
                            return true
                        } else {
                            return false
                        }
                    }
                    
                    // Adiciona elemento escolhido ao array
                    if !status{
                        // Animação
                        DispatchQueue.main.async {
                            withAnimation(.easeOut) {
                                self.elementosSelecionados.append(Imagem(id: self.elementosSelecionados.count, image: "\(url!)"))
                            }
                        }
                    }
                }
            } else {
                print("Cannot be loaded")
            }
        }
        
        return true
    }
}

struct Imagem {
    
    let id: Int
    let image: String
}

struct DadosElementos {
//    var totalImagens: [Elemento] = [
//        Elemento(id: UUID(), image: "Branca de Neve"),       Elemento(id: UUID(), image: "Chapéuzinho Vermelho"),
//        Elemento(id: UUID(), image: "Cinderella"),           Elemento(id: UUID(), image: "João e Maria"),
//        Elemento(id: UUID(), image: "Patinho Feio"),         Elemento(id: UUID(), image: "Espada de Diamantes"),
//        Elemento(id: UUID(), image: "Foguete"),              Elemento(id: UUID(), image: "Máquina do Tempo"),
//        Elemento(id: UUID(), image: "Minecraft"),            Elemento(id: UUID(), image: "Mundo Atual"),
//        Elemento(id: UUID(), image: "Vassoura Voadora")
//    ]
    
    static let elemento1 = ObjetoHistoria(id: UUID(),
                                          nome: "Branca de Neve",
                                          imagem: "Branca de Neve",
                                          tipo: "Personagem")
    
    static let elemento2 = ObjetoHistoria(id: UUID(),
                                          nome: "Chapeuzinho Vermelho",
                                          imagem: "Chapeuzinho Vermelho",
                                          tipo: "Personagem")
    
    static let elemento3 = ObjetoHistoria(id: UUID(),
                                          nome: "Cinderella",
                                          imagem: "Cinderella",
                                          tipo: "Personagem")
    
    static let elemento4 = ObjetoHistoria(id: UUID(),
                                          nome: "Joao e Maria",
                                          imagem: "Joao e Maria",
                                          tipo: "Personagem")
    
    static let elemento5 = ObjetoHistoria(id: UUID(),
                                          nome: "Patinho Feio",
                                          imagem: "Patinho Feio",
                                          tipo: "Personagem")
    
    static let elemento6 = ObjetoHistoria(id: UUID(),
                                          nome: "Espada de Diamantes",
                                          imagem: "Espada de Diamantes",
                                          tipo: "Objeto")
    
    static let elemento7 = ObjetoHistoria(id: UUID(),
                                          nome: "Foguete",
                                          imagem: "Foguete",
                                          tipo: "Objeto")
    
    static let elemento8 = ObjetoHistoria(id: UUID(),
                                          nome: "Maquina do Tempo",
                                          imagem: "Maquina do Tempo",
                                          tipo: "Objeto")
    
    static let elemento9 = ObjetoHistoria(id: UUID(),
                                          nome: "Minecraft",
                                          imagem: "Minecraft",
                                          tipo: "Cenário")
    
    static let elemento10 = ObjetoHistoria(id: UUID(),
                                           nome: "Mundo Moderno",
                                           imagem: "Mundo Moderno",
                                           tipo: "Cenário")
    
    static let elemento11 = ObjetoHistoria(id: UUID(),
                                           nome: "Vassoura Voadora",
                                           imagem: "Vassoura Voadora",
                                           tipo: "Objeto")
}

struct ObjetoHistoria: Codable, Hashable, Transferable, Identifiable {
    
    let id: UUID
    let nome: String
    let imagem: String
    let tipo: String
    
    
    static var transferRepresentation: some TransferRepresentation {
        CodableRepresentation(contentType: .objetoHistoria)
    }
}

struct SymbolToggleStyle: ToggleStyle {
 
    var systemImage: String = "checkmark"
    var activeColor: Color = .green
 
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            configuration.label
 
            Spacer()
 
            RoundedRectangle(cornerRadius: 30)
                .fill(configuration.isOn ? activeColor : Color(.systemGray5))
                .overlay {
                    Circle()
                        .fill(.white)
                        .padding(3)
                        .overlay {
                            Image(systemName: systemImage)
                                .foregroundColor(configuration.isOn ? activeColor : Color(.systemGray5))
                        }
                        .offset(x: configuration.isOn ? 10 : -10)
 
                }
                .frame(width: 50, height: 32)
                .onTapGesture {
                    withAnimation(.spring()) {
                        configuration.isOn.toggle()
                    }
                }
        }
    }
}

// MARK: Cria uma view polimorfica com alguns rounded corners
struct CornerRadiusShape: Shape {
    var radius = CGFloat.infinity
    var corners = UIRectCorner.allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

struct CornerRadiusStyle: ViewModifier {
    var radius: CGFloat
    var corners: UIRectCorner

    func body(content: Content) -> some View {
        content
            .clipShape(CornerRadiusShape(radius: radius, corners: corners))
    }
}

struct BlurView: UIViewRepresentable {
    func makeUIView(context: Context) -> UIVisualEffectView {
        let view = UIVisualEffectView(effect: UIBlurEffect(style: .systemUltraThinMaterial))
        
        return view
    }

    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        
    }
}

struct RoundedTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(.vertical)
            .padding(.horizontal, 24)
            .background(Color(uiColor: .systemGray6))
            .clipShape(Capsule(style: .continuous))
    }
}

struct RoundedTextFieldStyleYellowBckg: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(.vertical)
            .padding(.horizontal, 24)
            .background(Color.yellowReg)
            .opacity(0.4)
            .clipShape(Capsule(style: .continuous))
    }
}

// MARK: Struct contador contendo as moedas e chaves
struct Contador {
    var chaves: Int
    var moedas: Int
}
