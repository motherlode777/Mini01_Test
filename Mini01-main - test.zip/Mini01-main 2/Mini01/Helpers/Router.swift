//
//  Router.swift
//  Mini01
//
//  Created by Letícia Malagutti on 25/07/23.
//

import SwiftUI

class Router: ObservableObject {
    @Published var path = NavigationPath()
    
    func reset() {
        path = NavigationPath()
    }
}
