//
//  Extensions.swift
//  Mini01
//
//  Created by Letícia Malagutti on 17/07/23.
//

import SwiftUI
import UniformTypeIdentifiers


extension Shape {
    func fill<Fill: ShapeStyle, Stroke: ShapeStyle>(_ fillStyle: Fill, strokeBorder strokeStyle: Stroke, lineWidth: Double = 1) -> some View {
        self
            .stroke(strokeStyle, lineWidth: lineWidth)
            .background(self.fill(fillStyle))
    }
}

extension InsettableShape {
    func fill<Fill: ShapeStyle, Stroke: ShapeStyle>(_ fillStyle: Fill, strokeBorder strokeStyle: Stroke, lineWidth: Double = 1) -> some View {
        self
            .strokeBorder(strokeStyle, lineWidth: lineWidth)
            .background(self.fill(fillStyle))
    }
}

extension View {
    // MARK: Criação da extensão para arredondar cantos específicos
    func cornerRadius(radius: CGFloat, corners: UIRectCorner) -> some View {
        ModifiedContent(content: self, modifier: CornerRadiusStyle(radius: radius, corners: corners))
    }
    
    func popupNavigationView<Content: View>(horizontalPadding: CGFloat = 40, show: Binding<Bool>, @ViewBuilder content: @escaping ()->Content) -> some View {
        
        GeometryReader { proxy in
            
            return self
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .overlay(alignment: .center) {
                    
                    if show.wrappedValue {
                        
                        Color.primary
                            .opacity(0.15)
                            .ignoresSafeArea()
                        
                        let size = proxy.size
                        
                        NavigationStack {
                            content()
                        }
                        .frame(width: size.width - horizontalPadding, height: size.height / 1.7, alignment: .center)
                        .cornerRadius(15)
                    }
                }
        }
    }
}

extension Color {
    static let escrita = Color("Escrita")
    
    static let greenReg = Color("GreenRegular")
    static let yellowReg = Color("YellowRegular")
    static let blueReg = Color("BlueRegular")
    static let greenLgt = Color("GreenLight")
    static let tealReg = Color("TealRegular")
    static let tealDrk = Color("TealDark")
    static let orangeReg = Color("OrangeRegular")
    static let redReg = Color("RedRegular")
}

enum CustomFont: String {
    case black = "Arboria-Black"
    case blackItalic = "Arboria-BlackItalic"
    case bold = "Arboria-Bold"
    case boldItalic = "Arboria-BoldItalic"
    case book = "Arboria-Book"
    case bookItalic = "Arboria-BookItalic"
    case light = "Arboria-Light"
    case lightItalic = "Arboria-LightItalic"
    case medium = "Arboria-Medium"
    case mediumItalic = "Arboria-MediumItalic"
    case thin = "Arboria-Thin"
    case thinItalic = "Arboria-ThinItalic"
}
extension Font {
    static func custom(_ font: CustomFont, size: CGFloat) -> SwiftUI.Font {
        SwiftUI.Font.custom(font.rawValue, size: size)
    }
}

extension UTType {
    static let objetoHistoria = UTType(exportedAs: "co.leticiamalagutti.Mini01")
}

