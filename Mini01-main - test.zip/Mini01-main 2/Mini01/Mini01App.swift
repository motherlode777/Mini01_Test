//
//  Mini01App.swift
//  Mini01
//
//  Created by Letícia Malagutti on 05/07/23.
//

import SwiftUI

@main
struct Mini01App: App {
    let persistenceController = PersistenceController.shared
    
    @StateObject var router = Router()
   
// // MARK: Descobrindo as especificações da fonte ARBORIA
//    init(){
//        printFonts()
//    }
//
//    func printFonts(){
//        let fontFamilyNames = UIFont.familyNames
//
//        for familyName in fontFamilyNames {
//            print("--------------")
//            print("Font Family Name -> [\(familyName)")
//
//            let name = UIFont.fontNames(forFamilyName: familyName)
//            print("Font Names ==> [\(name)]")
//        }
//    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .environmentObject(router)
        }
    }
}
