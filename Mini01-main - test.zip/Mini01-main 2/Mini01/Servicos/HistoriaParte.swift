//
//  HistoriaParte.swift
//  Mini01
//
//  Created by Fabio Freitas on 20/07/23.
//

import Foundation
import SWXMLHash

struct HistoriaParte {
    let tituloDaParte: String
    let paragrafos: [String]
    let pergunta: String?
    let escolhas: [String]?
    
    static let totalDePartes: Int = 5
}

extension HistoriaParte: XMLObjectDeserialization {
    static func deserialize(_ element: XMLIndexer) throws -> HistoriaParte {
        return try HistoriaParte(
            tituloDaParte: element["title"].value(),
            paragrafos: element["paragraphs"]["paragraph"].value(),
            pergunta: element["interaction"]["question"].value(),
            escolhas: element["interaction"]["choices"]["choice"].value()
        )
    }
}

extension HistoriaParte {
    private static let XMLHasher = XMLHash.config({ cfg in cfg.detectParsingErrors = true })
    static func converterParte(resposta: String, parteFinal: Bool = false) throws -> HistoriaParte {
        do {
            let parteConvertida = XMLHasher.parse(resposta)
            if (parteFinal) {
                let final: HistoriaParte = try parteConvertida["finalpart"].value()
                return final
            }
            let proxima: HistoriaParte = try parteConvertida["part"].value()
            return proxima
        } catch {
            print("Houve um problema ao resposta do GPT em HistoriaParte")
            print(error.localizedDescription.debugDescription)
            throw ErroServico.RespostaInvalida
        }
    }
}
