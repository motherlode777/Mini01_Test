//
//  ErroServico.swift
//  Mini01
//
//  Created by Fabio Freitas on 20/07/23.
//

import Foundation


enum ErroServico: Error {
    case RequisicaoInvalida
    case RespostaInvalida
}
