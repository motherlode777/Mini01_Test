//
//  OpenaiAPI.swift
//  Mini01
//
//  Created by Fabio Freitas on 14/07/23.
//

import Foundation
import Alamofire

struct ChatMessage: Codable, Identifiable {
    let id: UUID
    let mensagem: OpenAIChatMessage
}

enum Role: String, Codable {
    case system
    case user
    case assistant
}
struct OpenAIChatMessage: Codable {
    let role: Role
    let content: String
}

struct OpenAIChatParameters: Codable {
    let model: String
    let messages: [OpenAIChatMessage]
    let max_tokens: Int?
}

struct OpenAIChatChoice: Codable { // A Api usa essa nomenclatura na resposta
    let message: OpenAIChatMessage
}

struct OpenAIChatResponse: Codable {
    let choices: [OpenAIChatChoice]
}

class OpenAIAPI {
    private let apiKey: String
    
    init() {
        // How to configure Secrets in SwiftUI: https://blog.arturofm.com/untitled-2/
//        apiKey = (Bundle.main.infoDictionary?["OPENAPI_KEY"] as? String)!
        apiKey = "" // MUDAR ISSO CASO USE A API DO GPT
        print("Configure a chave da api")
    }
    
    private let endpoint: String = "https://api.openai.com/v1/chat/completions"
    private let modelo = "gpt-3.5-turbo-16k"
    private var headers: HTTPHeaders {
        return  [
            "Authorization": "Bearer \(apiKey)"
        ]
    }
    
    func enviarPrompt(mensagensEnviadas: [OpenAIChatMessage] ) async throws -> OpenAIChatMessage {
        let body = OpenAIChatParameters(model: modelo, messages: mensagensEnviadas, max_tokens: nil)

        do {
            let respostaAPI = try await AF.request(endpoint, method: .post, parameters: body, encoder: .json, headers: headers).serializingDecodable(OpenAIChatResponse.self).value
            if let mensagemResposta = respostaAPI.choices.first?.message {
                return mensagemResposta
            }
                throw ServiceError.InvalidResponse
        } catch {
                print("Houve um problema ao enviar o prompt:")
                print(error.localizedDescription.debugDescription)
                throw ServiceError.InvalidRequest
        }
    }
}
