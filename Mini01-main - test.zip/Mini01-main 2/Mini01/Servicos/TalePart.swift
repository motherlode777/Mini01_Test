//
//  HistoriaParte.swift
//  Mini01
//
//  Created by Fabio Freitas on 20/07/23.
//

import Foundation
import SWXMLHash

struct TalePart {
    let partTitle: String
    let paragraphs: [String]
    let question: String?
    let choices: [String]?
    
    static let totalDePartes: Int = 3
}

extension TalePart: XMLObjectDeserialization {
    static func deserialize(_ element: XMLIndexer) throws -> TalePart {
        return try TalePart(
            partTitle: element["title"].value(),
            paragraphs: element["paragraphs"]["paragraph"].value(),
            question: element["question"]["interaction"].value(),
            choices: element["question"]["choices"]["choice"].value()
        )
    }
}

extension TalePart {
    private static let XMLHasher = XMLHash.config({ cfg in cfg.detectParsingErrors = true })
    static func convertIntoPart(textContent: String, finalPart: Bool = false) throws -> TalePart {
        do {
            let parteConvertida = XMLHasher.parse(textContent)
            if (finalPart) {
                let final: TalePart = try parteConvertida["finalpart"].value()
                return final
            }
            let proxima: TalePart = try parteConvertida["part"].value()
            return proxima
        } catch {
            print("Houve um problema ao converter a resposta do GPT em HistoriaParte")
            print(error.localizedDescription.debugDescription)
            throw ServiceError.InvalidResponse
        }
    }
}

let fakePart = """
<?xml version="1.0" encoding="UTF-8"?>
<part>
    <title>Parte 4: O Baile Real</title>
    <paragraphs>
        <paragraph>As irmãs de Cinderela, com inveja da possibilidade dela ir ao baile real, a trancaram no sótão da casa. Parecia que seu sonho estava prestes a se despedaçar, mas Cinderela não perdeu a esperança. Enquanto estava no sótão, ela avistou uma pequena janela e viu uma misteriosa coruja empoleirada.</paragraph>
        <paragraph>A coruja, que era na verdade uma fada disfarçada, ouviu os desejos de Cinderela e, com sua varinha mágica, desfez os cadeados que a prendiam. Num piscar de olhos, a jovem estava livre novamente. A fada disse a Cinderela que acreditava na sua bondade e que estava lá para ajudá-la a realizar seu desejo de ir ao baile real.</paragraph>
        <paragraph>A fada revelou sua verdadeira identidade para Cinderela. Ela era, na verdade, uma rainha de um reino distante que estava passando por um teste para encontrar a pessoa mais digna e gentil para receber uma poderosa Espada de Diamante, capaz de realizar desejos.</paragraph>
        <paragraph>A rainha estava impressionada com a bondade de Cinderela e sua coragem diante das dificuldades. Por isso, ofereceu a ela a chance de ir ao baile real, com a condição de que retornasse antes da meia-noite, quando o feitiço se desfaria. Além disso, a rainha concedeu a Cinderela a Espada de Diamante para usar caso precisasse de ajuda.</paragraph>

    </paragraphs>
    <question>
        <interaction>O que a Espada de Diamante concedia a quem a possuía?</interaction>
        <choices>
            <choice> A habilidade de controlar o tempo.</choice>
            <choice> O poder de se teletransportar.</choice>
            <choice> A capacidade de voar como um pássaro.</choice>
            <choice> A realização de desejos.</choice>
        </choices>
    </question>
</part>
"""

let fakeFinalPart = """
<?xml version="1.0" encoding="UTF-8"?>
<finalpart>
    <title>Parte Final: O Final Encantado</title>
    <paragraphs>
        <paragraph>Com a Espada de Diamante em mãos, Cinderela partiu para o baile real. Chegando lá, ela estava deslumbrante em seu belo vestido e encantou a todos com sua graciosidade. Os olhares curiosos se voltavam para ela, sem que ninguém soubesse quem ela realmente era.</paragraph>
        <paragraph>No meio do baile, um grupo de jovens nobres começou a zombar de Cinderela, pensando que ela era apenas uma plebeia comum. Mas, lembrando-se da capacidade de voar como um pássaro que a Espada de Diamante lhe concedia, ela ergueu a espada e, num piscar de olhos, pairou sobre o salão, deixando todos boquiabertos.</paragraph>
        <paragraph>Enquanto Cinderela flutuava graciosa pelo ar, ela finalmente conheceu o príncipe do reino, que ficou encantado com sua beleza e elegância. Eles dançaram juntos a noite toda, e Cinderela sentiu-se feliz como nunca antes.</paragraph>
        <paragraph>No entanto, ao se aproximar da meia-noite, Cinderela lembrou-se do aviso da rainha e sabia que precisava voltar antes que o feitiço se desfizesse. Ela disse adeus ao príncipe e, usando a Espada de Diamante, voou de volta para casa.</paragraph>
    </paragraphs>
</finalpart>
"""
