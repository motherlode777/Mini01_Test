//
//  GoogleVoiceAPI.swift
//  Mini01
//
//  Created by Bruno Teodoro on 26/07/23.
//

import Foundation
import AVFoundation

var userLanguage = Locale.current.language.languageCode == "pt" && Locale.current.language.region == "BR" ? "pt-BR" : "pt-BR"

enum VoiceType: String {
    case undefined
    case ptBR = "pt-BR-Neural2-C"
    case enUS = "en-US-Neural2-F"
}

class AudioPlayerManager {
    var audioPlayer: AVAudioPlayer?
    var currentPlaybackTime: TimeInterval = 0.0
    
    init() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback)
        } catch {
            print("Error setting up audio session: \(error.localizedDescription)")
        }
    }
    
    func playAudio(fromBase64String base64String: String) {
        guard let data = Data(base64Encoded: base64String) else {
            print("Invalid Base64 data for audio.")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(data: data)
            audioPlayer?.currentTime = currentPlaybackTime
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
        } catch {
            print("Error playing audio: \(error.localizedDescription)")
        }
    }
    
    func pauseAudio() {
        if let player = audioPlayer, player.isPlaying {
            player.pause()
            currentPlaybackTime = player.currentTime
        }
    }
    
    func resetAudio() {
        audioPlayer?.stop()
        audioPlayer = nil
        currentPlaybackTime = 0.0
    }
}


let ttsAPIUrl = "https://texttospeech.googleapis.com/v1/text:synthesize"
let APIKey = ""

class SpeechService: NSObject, AVAudioPlayerDelegate {
    static let voice = SpeechService()
    private(set) var busy: Bool = false
    
    private var player: AVAudioPlayer?
    private var completionHandler: (() -> Void)?
    
    func speak(text: String, voiceType: VoiceType, completion: @escaping (String) -> Void) {
        var audioString: String = "TESTE"
        
        guard !self.busy else {
            print("Speech Service busy!")
            completion("")
            return
        }
        
        self.busy = true
        
        DispatchQueue.global(qos: .background).async {
            let postData = self.buildPostData(text: text, voiceType: voiceType)
            let headers = ["X-Goog-Api-Key": APIKey, "Content-Type": "application/json; charset=utf-8"]
            let response = self.makePOSTRequest(url: ttsAPIUrl, postData: postData, headers: headers)
            
            // Get the `audioContent` (as a base64 encoded string) from the response.
            guard let audioContent = response["audioContent"] as? String else {
                print("Invalid response: \(response)")
                self.busy = false
                DispatchQueue.main.async {
                    completion("")
                }
                return
            }
            
            audioString = audioContent
            
            DispatchQueue.main.async {
                self.busy = false
                completion(audioString)
                print("success")
            }
        }
    }
    
    private func buildPostData(text: String, voiceType: VoiceType) -> Data {
        var voiceParams: [String: Any] = [
            "languageCode": "\(userLanguage)"
        ]
        
        if voiceType != .undefined {
            voiceParams["name"] = voiceType.rawValue
        }
        
        let params: [String: Any] = [
            "input": [
                "text": text
            ],
            "voice": voiceParams,
            "audioConfig": [
                "audioEncoding": "LINEAR16"
            ]
        ]
        
        // Convert the Dictionary to Data
        let data = try! JSONSerialization.data(withJSONObject: params)
        return data
    }
    
    // Just a function that makes a POST request.
    private func makePOSTRequest(url: String, postData: Data, headers: [String: String] = [:]) -> [String: AnyObject] {
        var dict: [String: AnyObject] = [:]
        
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.httpBody = postData
        
        for header in headers {
            request.addValue(header.value, forHTTPHeaderField: header.key)
        }
        
        // Using semaphore to make request synchronous
        let semaphore = DispatchSemaphore(value: 0)
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: AnyObject] {
                dict = json
            }
            
            semaphore.signal()
        }
        
        task.resume()
        _ = semaphore.wait(timeout: DispatchTime.distantFuture)
        
        return dict
    }
    
    // Implement AVAudioPlayerDelegate "did finish" callback to cleanup and notify listener of completion.
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        self.player?.delegate = nil
        self.player = nil
        self.busy = false
        
        self.completionHandler?()
        self.completionHandler = nil
    }
}



