//
//  ErroServico.swift
//  Mini01
//
//  Created by Fabio Freitas on 20/07/23.
//

import Foundation


enum ServiceError: Error {
    case InvalidRequest
    case InvalidResponse
}
