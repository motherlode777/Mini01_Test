//
//  DesenhoView.swift
//  Mini01
//
//  Created by GABRIEL Ferreira Cardoso on 21/07/23.
//

import SwiftUI
import PencilKit

struct DesenhoView: View {
    
    @State var canvasSize = UIScreen.main.bounds.size
    @State var canvasView = PKCanvasView()
    @Environment(\.managedObjectContext) var managedObjectContext
    
    
    var body: some View {
        
        NavigationStack {
            
            Button("Save") {
                
                let newdesenho = Historia(context: managedObjectContext)
                newdesenho.desenhocapa = canvasView.drawing.image(from: .init(origin: .zero, size: canvasSize), scale: 1.0).pngData()
                newdesenho.id  = UUID()
                newdesenho.timestamp = Date()
                try? managedObjectContext.save()
                print("salvou")
                
            }
            
            NavigationLink(destination: MinhasHistoriasView()) {
                Text("Concluir")
            }
            
            PencilKitView(canvasSize: $canvasSize, canvasView: $canvasView)
                .navigationTitle("Desenho")
        }
    }
}

struct DesenhoView_Previews: PreviewProvider {
    static var previews: some View {
        DesenhoView()
            .environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
