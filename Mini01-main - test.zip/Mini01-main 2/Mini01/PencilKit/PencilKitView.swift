//
//  PencilKitView.swift
//  Mini01
//
//  Created by GABRIEL Ferreira Cardoso on 25/07/23.
//

import SwiftUI
import PencilKit

//Canvas do PencilKit (área de desenho)
struct PencilKitView: UIViewRepresentable {
    
    @Binding var canvasSize: CGSize
    @Binding var canvasView: PKCanvasView
    
    typealias UIViewType = PKCanvasView
    
    let toolPicker = PKToolPicker()
    
    func makeUIView(context: Context) -> PKCanvasView {
        
        canvasView.contentSize = canvasSize
        canvasView.drawingPolicy = .anyInput
        toolPicker.addObserver(canvasView)
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        canvasView.becomeFirstResponder()
        
        return canvasView
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(canvasView)
    }
}
